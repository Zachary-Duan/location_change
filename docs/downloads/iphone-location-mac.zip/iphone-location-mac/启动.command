#!/bin/zsh
set -eu
cd -- "${0:A:h}"
location_temp=""
location_locked=0
function location_cleanup() {
  [[ -z "$location_temp" ]] || /bin/rm -rf -- "$location_temp"
  if [[ "$location_locked" == 1 ]]; then /bin/rmdir .runtime/setup.lock 2>/dev/null || true; fi
}
trap location_cleanup EXIT
function location_fail() {
  print -r -- "$1"
  print '未更改手机定位。关闭窗口后可重新双击启动。'
  if [[ -t 0 ]]; then read '?按回车关闭…' || true; fi
  exit 1
}
[[ "$(/usr/bin/uname -s)" == Darwin ]] || location_fail '此助手需要在 Mac 上运行。'
location_major="$(/usr/bin/sw_vers -productVersion)"
[[ "${location_major%%.*}" -ge 13 ]] || location_fail '自动安装版需要 macOS 13 或更新版本。'
umask 077
/bin/mkdir -p .runtime || location_fail '请先把助手完整解压到有写入权限的文件夹，例如“下载”文件夹。'
if ! /bin/mkdir .runtime/setup.lock 2>/dev/null; then
  location_fail '另一个启动窗口正在准备组件，请先回到那个窗口。若已全部关闭，可删除 .runtime/setup.lock 空文件夹后重试。'
fi
location_locked=1
export UV_PYTHON_INSTALL_DIR="$PWD/.runtime/python"
export UV_CACHE_DIR="$PWD/.runtime/cache"
export UV_PYTHON_INSTALL_BIN=0 UV_NO_CONFIG=1 UV_PYTHON_PREFERENCE=only-managed
export UV_CONCURRENT_DOWNLOADS=4 UV_HTTP_TIMEOUT=60
export LOCATION_STATE_DIR="$PWD/.runtime"
location_hash="$(/usr/bin/shasum -a 256 requirements.txt | /usr/bin/cut -d ' ' -f 1)"
location_ready=0
if [[ -x .venv/bin/python && -f .runtime/dependencies.sha256 ]]; then
  if [[ "$(<.runtime/dependencies.sha256)" == "$location_hash" ]] && .venv/bin/python -c 'import sys; from pathlib import Path; from importlib.metadata import version; import pymobiledevice3, click, construct, cryptography, requests; assert sys.version_info >= (3, 11); assert version("pymobiledevice3") == "11.12.5"; assert Path(sys.prefix).resolve() == (Path.cwd()/".venv").resolve(); assert Path(sys.base_prefix).resolve().is_relative_to((Path.cwd()/".runtime/python").resolve())' >/dev/null 2>&1; then
    location_ready=1
  fi
fi
if [[ "$location_ready" == 0 ]]; then
  case "$(/usr/bin/uname -m)" in
    arm64) location_arch=aarch64-apple-darwin; location_checksum=7e6ddb9316acc00f2296c82ff4d99977870ee34b2f0ddcae9444d714db9364ed ;;
    x86_64) location_arch=x86_64-apple-darwin; location_checksum=5e287ef61cb6a9b61b3a83fef124fd143e400468a7dac794230147a810e17119 ;;
    *) location_fail '暂不支持这台 Mac 的处理器。' ;;
  esac
  location_uv="$PWD/.runtime/uv-0.12.13-$location_arch/uv"
  print '首次启动：自动准备运行组件。无需另外安装 Python，请保持网络连接。'
  if [[ ! -x "$location_uv" ]]; then
    location_temp="$(/usr/bin/mktemp -d "$PWD/.runtime/install.XXXXXX")" || location_fail '无法创建下载目录。'
    print '1/3 下载运行工具…'
    /usr/bin/curl --fail --location --proto '=https' --tlsv1.2 --connect-timeout 15 --max-time 240 --retry 2 --output "$location_temp/uv.tar.gz" "https://github.com/astral-sh/uv/releases/download/0.12.13/uv-$location_arch.tar.gz" || location_fail '运行工具下载失败，请检查网络后重试。'
    location_actual="$(/usr/bin/shasum -a 256 "$location_temp/uv.tar.gz" | /usr/bin/cut -d ' ' -f 1)"
    [[ "$location_actual" == "$location_checksum" ]] || location_fail '下载文件校验失败，已停止安装，请重新下载。'
    /usr/bin/tar -xzf "$location_temp/uv.tar.gz" -C "$location_temp" || location_fail '运行工具解压失败。'
    /bin/mv "$location_temp/uv-$location_arch" "${location_uv:h}" || location_fail '无法保存运行工具。'
    /bin/rm -rf -- "$location_temp"
    location_temp=""
  fi
  print '2/3 自动准备 Python…'
  "$location_uv" venv --python 3.12 --clear .venv || location_fail 'Python 组件下载或创建失败，请检查网络与可用空间后重试。'
  print '3/3 安装 iPhone 连接组件…'
  "$location_uv" pip install --python "$PWD/.venv/bin/python" -r requirements.txt || location_fail '连接组件下载未完成，请检查网络后重试。'
  "$location_uv" pip check --python "$PWD/.venv/bin/python" || location_fail '连接组件不完整，请重新启动以修复。'
  print -r -- "$location_hash" > .runtime/dependencies.sha256
fi
/bin/rmdir .runtime/setup.lock
location_locked=0
if [[ "${LOCATION_SETUP_ONLY:-0}" == 1 ]]; then print '运行组件已准备完成。'; exit 0; fi
print '准备完成，正在打开地图控制台…'
exec "$PWD/.venv/bin/python" server.py --port 8765 --open
