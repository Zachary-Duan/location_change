"""Isolated device jobs. stdout is JSON events; each session owns its transport."""
import asyncio
import contextlib
import json
import logging
import os
from pathlib import Path
import signal
import struct
import sys
import threading


def emit(event, **values):
    # ASCII JSON also works when Windows starts the worker with a legacy code page.
    print(json.dumps({"event": event, **values}, ensure_ascii=True), flush=True)


def explain(error):
    name = type(error).__name__
    if sys.platform == "win32" and name == "ConnectionFailedToUsbmuxdError":
        return "未连接到 Apple 手机服务。请安装并打开 Microsoft Store 版 iTunes，确认 Apple Mobile Device Service 正在运行，再连接并信任 iPhone。"
    if isinstance(error, TimeoutError):
        return "连接超时。请解锁手机、检查信任与开发者模式，然后重试。"
    if isinstance(error, PermissionError):
        return "电脑阻止了设备连接。请从启动脚本运行，或检查本地程序的访问权限。"
    if any(s in name.lower() for s in ("pair", "password", "locked")):
        return "请解锁 iPhone，并在手机及电脑的 Apple 设备管理窗口中确认信任，再重试。"
    if "DeveloperMode" in name:
        return "请在 iPhone 的设置 → 隐私与安全性中开启开发者模式，并完成重启确认。"
    if any(s in name for s in ("InvalidService", "NotMounted", "Image")):
        return "开发者连接尚未就绪。请先点击“准备连接”，并确认手机的开发者模式已开启。"
    return f"{name}: {str(error)[:250] or '设备连接失败，请检查手机连接并重试。'}"


async def discover():
    from pymobiledevice3.usbmux import list_devices
    from pymobiledevice3.lockdown import create_using_usbmux
    result = []
    for device in await list_devices():
        if not device.is_usb:
            continue
        entry = {"id": device.serial, "name": "USB 设备（待信任）", "version": "", "paired": False}
        try:
            async with await asyncio.wait_for(create_using_usbmux(device.serial, autopair=False, connection_type="USB"), 5) as lockdown:
                info = lockdown.short_info
                if info.get("DeviceClass") not in (None, "iPhone"):
                    continue
                entry.update(name=info.get("DeviceName") or "iPhone", version=info.get("ProductVersion") or "", paired=lockdown.paired)
        except Exception as error:
            entry["hint"] = explain(error)
        result.append(entry)
    emit("devices", devices=result)


async def require_usb(udid):
    from pymobiledevice3.usbmux import list_devices
    if not any(d.serial == udid and d.is_usb for d in await list_devices()):
        raise RuntimeError("所选 iPhone 没有通过 USB 连接，请连接后刷新设备。")


async def connect_lockdown(udid):
    from pymobiledevice3.lockdown import create_using_usbmux
    return await create_using_usbmux(udid, connection_type="USB", pair_timeout=20)


def check_platform_version(version):
    parts = [int(part) for part in version.split(".")[:2]]
    major, minor = (parts + [0])[:2]
    if sys.platform == "win32" and major < 13:
        raise RuntimeError("Windows 简易版需要 iOS 13 或更新版本。")
    if sys.platform == "win32" and major == 17 and minor < 4:
        raise RuntimeError("Windows 简易连接暂不支持 iOS 17.0–17.3.x。请使用 iOS 17.4 或更新版本的设备，或使用 Mac 版助手。")
    return major


def install_stop_signals(loop, stop):
    for sig in (signal.SIGINT, signal.SIGTERM):
        if sys.platform == "win32":
            signal.signal(sig, lambda *_: loop.call_soon_threadsafe(stop.set))
        else:
            loop.add_signal_handler(sig, stop.set)


async def read_control(stop):
    loop = asyncio.get_running_loop()
    if sys.platform != "win32":
        reader = asyncio.StreamReader()
        transport, _ = await loop.connect_read_pipe(lambda: asyncio.StreamReaderProtocol(reader), sys.stdin)
        try:
            while True:
                line = await reader.readline()
                if not line or line.strip() == b"stop":
                    stop.set()
                    return
        finally:
            transport.close()
    else:
        # Windows Popen pipes are not overlapped handles. A daemon uses raw reads,
        # avoiding both unsupported asyncio pipes and a buffered-stdin shutdown lock.
        finished = threading.Event()
        descriptor = sys.stdin.fileno()

        def receive():
            pending = b""
            try:
                while not finished.is_set():
                    data = os.read(descriptor, 64)
                    lines = (pending + data).split(b"\n")
                    pending = lines.pop()
                    if not data or any(line.strip() == b"stop" for line in lines):
                        break
                    if len(pending) > 1024:
                        pending = b""
                else:
                    return
            except OSError:
                pass
            if not finished.is_set():
                with contextlib.suppress(RuntimeError):
                    loop.call_soon_threadsafe(stop.set)

        threading.Thread(target=receive, name="location-control", daemon=True).start()
        try:
            await stop.wait()
        finally:
            finished.set()


async def prepare(udid):
    from pymobiledevice3.exceptions import AlreadyMountedError
    from pymobiledevice3.services.mobile_image_mounter import auto_mount
    await require_usb(udid)
    async with await connect_lockdown(udid) as lockdown:
        major = check_platform_version(lockdown.product_version)
        if major >= 16 and not await lockdown.get_developer_mode_status():
            raise RuntimeError("请先在 iPhone 上开启开发者模式，并完成重启后的确认。")
        with contextlib.suppress(AlreadyMountedError):
            await auto_mount(lockdown)
    emit("prepared")


class LegacyLocation:
    """Close each legacy service explicitly; its protocol provides no acknowledgement."""
    def __init__(self, lockdown):
        self.lockdown = lockdown

    async def set(self, latitude, longitude):
        service = await self.lockdown.start_lockdown_developer_service("com.apple.dt.simulatelocation")
        async with service:
            values = [str(latitude).encode(), str(longitude).encode()]
            await service.sendall(struct.pack(">I", 0) + b"".join(struct.pack(">I", len(v)) + v for v in values))

    async def clear(self):
        service = await self.lockdown.start_lockdown_developer_service("com.apple.dt.simulatelocation")
        async with service:
            await service.sendall(struct.pack(">I", 1))


async def simulation(udid, latitude, longitude, clear_only=False):
    from pymobiledevice3.remote.rsd_tunnel import PreferredRsdTunnel
    from pymobiledevice3.services.dvt.instruments.dvt_provider import DvtProvider
    from pymobiledevice3.services.dvt.instruments.location_simulation import LocationSimulation
    from pymobiledevice3.usbmux import list_devices
    loop = asyncio.get_running_loop()
    stop = asyncio.Event()
    lost = asyncio.Event()
    tasks = []
    install_stop_signals(loop, stop)

    async def check_usb():
        while True:
            await asyncio.sleep(3)
            try:
                devices = await asyncio.wait_for(list_devices(), 5)
                if not any(d.serial == udid and d.is_usb for d in devices):
                    lost.set()
                    return
            except Exception:
                lost.set()
                return

    control_task = asyncio.create_task(read_control(stop))
    async with contextlib.AsyncExitStack() as stack:
        async def finish_control():
            control_task.cancel()
            await asyncio.gather(control_task, return_exceptions=True)
        stack.push_async_callback(finish_control)
        # Include acquisition and set in one deadline, without wrapping the whole held session.
        async with asyncio.timeout(55):
            await require_usb(udid)
            lockdown = await stack.enter_async_context(await connect_lockdown(udid))
            major = check_platform_version(lockdown.product_version)
            if major >= 16 and not await lockdown.get_developer_mode_status():
                raise RuntimeError("请先开启 iPhone 开发者模式，重启并确认后再试。")
            if major >= 17:
                tunnel = PreferredRsdTunnel(serial=udid)
                # Register cleanup before aopen so partial acquisition can be released.
                stack.push_async_callback(tunnel.aclose)
                rsd = await tunnel.aopen()
                dvt = await stack.enter_async_context(DvtProvider(rsd))
                location = await stack.enter_async_context(LocationSimulation(dvt))
                location.service.on_closed = lambda reason="": lost.set()
            else:
                location = LegacyLocation(lockdown)
            if clear_only:
                await location.clear()
                emit("cleared")
                return
            # Give the pipe reader a turn before sending a mutation. A stop requested
            # during pairing or tunnel setup must not first apply the cancelled target.
            await asyncio.sleep(0)
            if stop.is_set():
                emit("cancelled")
                return
            await location.set(latitude, longitude)
            if lost.is_set():
                raise ConnectionError("发送过程中连接中断，手机定位状态待确认。")
            emit("sent", acknowledged=major >= 17)
        try:
            tasks = [control_task, asyncio.create_task(check_usb()),
                     asyncio.create_task(stop.wait()), asyncio.create_task(lost.wait())]
            await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
            if lost.is_set():
                raise ConnectionError("连接中断。手机定位状态待确认；重新连接后点击停止模拟。")
            await asyncio.wait_for(location.clear(), 12)
            emit("cleared")
        finally:
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)


async def main():
    # This pinned library has no public per-app cache option. Redirect its cache before
    # importing consumers; do not write pairing records into the user's home directory.
    import pymobiledevice3.common as common
    common._HOMEFOLDER = Path(os.environ.get("LOCATION_STATE_DIR", str(Path(__file__).parent / ".runtime")))
    common._HOMEFOLDER.mkdir(parents=True, exist_ok=True, mode=0o700)
    action = sys.argv[1]
    if action == "list":
        await asyncio.wait_for(discover(), 20)
    elif action == "prepare":
        await prepare(sys.argv[2])
    elif action == "set":
        await simulation(sys.argv[2], float(sys.argv[3]), float(sys.argv[4]))
    elif action == "clear":
        await simulation(sys.argv[2], 0, 0, clear_only=True)
    else:
        raise ValueError("Unknown operation")


if __name__ == "__main__":
    os.umask(0o077)
    logging.basicConfig(level=logging.ERROR, stream=sys.stderr)
    try:
        asyncio.run(main())
    except Exception as error:
        emit("error", message=explain(error))
        sys.exit(1)
