﻿# Coordinate formula reference

`dist/coordinates.js` adapts the GCJ-02 mathematical model used by
[coordtransform](https://github.com/wandergis/coordtransform), adding an iterative
inverse, input validation and explicit conversion opt-out.

The MIT License (MIT)

Copyright (c) 2015 记忆的残骸

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


## Leaflet 1.9.4

默认地图使用 Leaflet 1.9.4 (BSD-2-Clause)，版权和完整许可见 `dist/vendor/LICENSE.txt`。JS/CSS 从官方列出的 unpkg 地址下载，并以官方 SHA-256 校验。

地图数据 © OpenStreetMap contributors，地图上显示归属链接。地点搜索由 Photon 公共服务提供，使用其 OpenStreetMap 数据。

uv 和 managed Python 在首次启动时从官方来源获取，按各自原许可证使用；下载包不内置这些二进制。
