﻿#Requires -Version 5.1
# This file is distributed as UTF-8 with BOM for Windows PowerShell 5.1.
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$locationLock = $null
$locationTemporary = $null
$locationExitCode = 1

function Invoke-LocationNative {
    param([string]$Program, [string[]]$Arguments, [string]$FailureMessage)
    # Windows PowerShell 5.1 must not turn normal native stderr progress into
    # a terminating NativeCommandError. Native exit codes remain authoritative.
    $previousPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        & $Program @Arguments
        $nativeExitCode = $LASTEXITCODE
    }
    finally { $ErrorActionPreference = $previousPreference }
    if ($nativeExitCode -ne 0) { throw "$FailureMessage (exit $nativeExitCode)" }
}

function Test-LocationRuntime {
    param([string]$Python)
    if (-not (Test-Path -LiteralPath $Python -PathType Leaf)) { return $false }
    $probe = "import sys; from pathlib import Path; from importlib.metadata import version; import pymobiledevice3, pymobiledevice3.usbmux, pymobiledevice3.remote.userspace_tunnel, click, construct, cryptography, requests; assert sys.version_info[:2] == (3, 12); assert version('pymobiledevice3') == '11.12.5'; assert Path(sys.prefix).resolve() == (Path.cwd()/'.venv').resolve(); assert Path(sys.base_prefix).resolve().is_relative_to((Path.cwd()/'.runtime/python').resolve())"
    $previousPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        & $Python -c $probe > $null 2> $null
        return ($LASTEXITCODE -eq 0)
    }
    catch { return $false }
    finally { $ErrorActionPreference = $previousPreference }
}

function Get-LocationDownload {
    param([string]$Uri, [string]$Destination)
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    for ($attempt = 1; $attempt -le 3; $attempt++) {
        try {
            Invoke-WebRequest -UseBasicParsing -Uri $Uri -OutFile $Destination -TimeoutSec 600
            return
        }
        catch {
            Remove-Item -LiteralPath $Destination -Force -ErrorAction SilentlyContinue
            if ($attempt -eq 3) { throw '运行工具下载失败。请检查网络后重新双击启动，已完成的组件会保留。' }
            Write-Host "下载暂未完成，正在重试（$attempt/2）…"
            Start-Sleep -Seconds 2
        }
    }
}

try {
    [Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
    $OutputEncoding = [Console]::OutputEncoding
    if ($env:OS -ne 'Windows_NT') { throw '此启动器只能在 Windows 上运行。' }
    $nativeArchitecture = $env:PROCESSOR_ARCHITECTURE
    if ($env:PROCESSOR_ARCHITEW6432) { $nativeArchitecture = $env:PROCESSOR_ARCHITEW6432 }
    if ($nativeArchitecture -ne 'AMD64') { throw '此版本支持 Intel / AMD 64 位 Windows，暂不支持 ARM 或 32 位 Windows。' }
    if ([Environment]::OSVersion.Version.Build -lt 19045) { throw '请使用 Windows 10 22H2 或 Windows 11。' }
    Set-Location -LiteralPath $PSScriptRoot
    foreach ($required in @('server.py', 'device_worker.py', 'requirements.txt', 'dist')) {
        if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot $required))) {
            throw '助手文件不完整。请先完整解压 ZIP 到可以写入的文件夹，再双击“启动.cmd”。'
        }
    }
    $runtime = Join-Path $PSScriptRoot '.runtime'
    [void][IO.Directory]::CreateDirectory($runtime)
    try {
        # Hold the handle until the server exits. A second launcher cannot clear
        # or change an environment while this copy is running. No stale lock
        # deletion is needed: Windows releases the handle if the process exits.
        $locationLock = [IO.File]::Open((Join-Path $runtime 'windows-launch.lock'), [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
    }
    catch { throw '这个文件夹的助手已在运行，或无法写入。请回到已有窗口；也可将助手完整解压到自己的“下载”文件夹。' }

    $env:LOCATION_STATE_DIR = $runtime
    $env:PYTHONUTF8 = '1'
    $env:PYTHONIOENCODING = 'utf-8'
    $env:UV_PYTHON_INSTALL_DIR = Join-Path $runtime 'python'
    $env:UV_CACHE_DIR = Join-Path $runtime 'cache'
    $env:UV_PYTHON_BIN_DIR = Join-Path $runtime 'bin'
    $env:UV_PYTHON_INSTALL_BIN = '0'
    $env:UV_PYTHON_INSTALL_REGISTRY = '0'
    $env:UV_PYTHON_NO_REGISTRY = '1'
    $env:UV_NO_CONFIG = '1'
    $env:UV_PYTHON_PREFERENCE = 'only-managed'
    $env:UV_CONCURRENT_DOWNLOADS = '4'
    $env:UV_HTTP_TIMEOUT = '60'
    $python = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
    $requirements = Join-Path $PSScriptRoot 'requirements.txt'
    $expectedRequirements = (Get-FileHash -LiteralPath $requirements -Algorithm SHA256).Hash
    $marker = Join-Path $runtime 'dependencies-windows.sha256'
    $ready = $false
    if ((Test-Path -LiteralPath $marker -PathType Leaf) -and ((Get-Content -LiteralPath $marker -Raw).Trim() -eq $expectedRequirements)) {
        $ready = Test-LocationRuntime -Python $python
    }
    if (-not $ready) {
        $uvDirectory = Join-Path $runtime 'uv-0.12.13-x86_64-pc-windows-msvc'
        $uv = Join-Path $uvDirectory 'uv.exe'
        $uvArchiveChecksum = 'a86c9dc7bad9b03f388583b7187c05fe9951c2e0d392217e8fd43d97787f6ec2'
        $archive = Join-Path $runtime 'uv-0.12.13-x86_64-pc-windows-msvc.zip'
        $validArchive = (Test-Path -LiteralPath $archive -PathType Leaf) -and ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash -eq $uvArchiveChecksum)
        Write-Host '首次启动或组件需要修复：自动准备运行组件，无需另外安装 Python。请保持网络连接。'
        $locationTemporary = Join-Path $runtime ('install-' + [Guid]::NewGuid().ToString('N'))
        [void][IO.Directory]::CreateDirectory($locationTemporary)
        if (-not $validArchive) {
            $download = Join-Path $locationTemporary 'uv.zip'
            Write-Host '1/3 下载并校验运行工具…'
            Get-LocationDownload -Uri 'https://github.com/astral-sh/uv/releases/download/0.12.13/uv-x86_64-pc-windows-msvc.zip' -Destination $download
            if ((Get-FileHash -LiteralPath $download -Algorithm SHA256).Hash -ne $uvArchiveChecksum) { throw '下载文件校验失败，已停止安装。请检查网络并重试。' }
            Move-Item -LiteralPath $download -Destination $archive -Force
        }
        # Always restore uv from the verified archive before executing it. A
        # corrupt or incomplete executable cache is never run during a repair.
        $unpacked = Join-Path $locationTemporary 'unpacked'
        Expand-Archive -LiteralPath $archive -DestinationPath $unpacked
        if (-not (Test-Path -LiteralPath (Join-Path $unpacked 'uv.exe') -PathType Leaf)) { throw '运行工具文件不完整，已停止安装。' }
        if (Test-Path -LiteralPath $uvDirectory) { Remove-Item -LiteralPath $uvDirectory -Recurse -Force }
        Move-Item -LiteralPath $unpacked -Destination $uvDirectory
        Remove-Item -LiteralPath $locationTemporary -Recurse -Force
        $locationTemporary = $null
        Remove-Item -LiteralPath $marker -Force -ErrorAction SilentlyContinue
        Write-Host '2/3 自动准备 Python…'
        Invoke-LocationNative -Program $uv -Arguments @('venv', '--python', '3.12', '--clear', (Join-Path $PSScriptRoot '.venv')) -FailureMessage 'Python 组件下载或创建失败，请检查网络与可用空间后重试。'
        Write-Host '3/3 安装 iPhone 连接组件…'
        Invoke-LocationNative -Program $uv -Arguments @('pip', 'install', '--python', $python, '-r', $requirements) -FailureMessage '连接组件下载未完成，请检查网络后重试。'
        Invoke-LocationNative -Program $uv -Arguments @('pip', 'check', '--python', $python) -FailureMessage '连接组件不完整，请重新启动以修复。'
        if (-not (Test-LocationRuntime -Python $python)) { throw '运行组件检查未通过，请重新启动以修复。' }
        [IO.File]::WriteAllText($marker, $expectedRequirements, [Text.Encoding]::ASCII)
    }
    if ($env:LOCATION_SETUP_ONLY -eq '1') {
        Write-Host '运行组件已准备完成（安装测试模式，未连接手机、未启动定位服务）。'
    }
    else {
        Write-Host '准备完成，正在打开地图控制台…'
        Write-Host '使用过程中请保持此窗口打开。结束模拟后可按 Ctrl+C 关闭助手。'
        Invoke-LocationNative -Program $python -Arguments @((Join-Path $PSScriptRoot 'server.py'), '--port', '8765', '--open') -FailureMessage '助手已停止。请查看上方错误，再重新启动。'
    }
    $locationExitCode = 0
}
catch {
    Write-Host ''
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host '请保留此窗口中的提示，处理后重新双击“启动.cmd”。'
}
finally {
    if ($locationTemporary -and (Test-Path -LiteralPath $locationTemporary)) { Remove-Item -LiteralPath $locationTemporary -Recurse -Force -ErrorAction SilentlyContinue }
    if ($null -ne $locationLock) { $locationLock.Dispose() }
}
exit $locationExitCode
