@echo off
setlocal DisableDelayedExpansion
title iPhone Location Assistant
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-windows.ps1"
set "location_exit_code=%errorlevel%"
if "%LOCATION_SETUP_ONLY%"=="1" exit /b %location_exit_code%
echo.
echo Assistant stopped. Press any key to close this window.
pause >nul
exit /b %location_exit_code%
