"""Isolated tests: no real AMap key, external requests, or iPhone commands."""
from email.message import Message
import http.client
import json
import os
import stat
import tempfile
import threading
import unittest
from unittest.mock import Mock, patch
from urllib.parse import parse_qs, urlsplit

from amap_config import AmapConfig, NoRedirect
from server import make_server

TEST_KEY = "test_key_not_a_real_credential_0000"
TEST_CODE = "test_security_not_a_real_secret_1111"


class ConfigTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.config = AmapConfig(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def save(self):
        return self.config.save({"key": TEST_KEY, "security_code": TEST_CODE})

    def test_missing_then_private_persistence(self):
        self.assertFalse(self.config.status()["configured"])
        public = self.save()
        self.assertTrue(public["configured"])
        self.assertNotIn(TEST_KEY, json.dumps(public))
        self.assertNotIn(TEST_CODE, json.dumps(public))
        if os.name != "nt":
            self.assertEqual(stat.S_IMODE(self.config.path.stat().st_mode), 0o600)
        self.assertEqual(AmapConfig(self.temp.name).read()["security_code"], TEST_CODE)
        self.assertFalse(self.config.clear()["configured"])

    def test_invalid_credentials_do_not_overwrite_saved_pair(self):
        self.save()
        for key in (None, True, "bad&jscode=evil", "<script>unsafe</script>"):
            with self.assertRaises(ValueError):
                self.config.save({"key": key, "security_code": TEST_CODE})
        self.assertEqual(self.config.read()["key"], TEST_KEY)

    def test_proxy_allows_only_fixed_api_paths(self):
        self.save()
        with patch("amap_config.build_opener") as network:
            for path in ("https://evil.example/api", "/v3/../other", "/v3/place/text/../../", "/api/start"):
                with self.assertRaises(ValueError): self.config.proxy(path, "")
            network.assert_not_called()

    def test_upstream_redirect_is_not_followed(self):
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
        from urllib.error import HTTPError
        from urllib.request import build_opener
        hits = []
        class Redirect(BaseHTTPRequestHandler):
            def log_message(self, *_): pass
            def do_GET(self):
                hits.append(self.path)
                self.send_response(302)
                self.send_header("Location", "/must-not-be-requested")
                self.end_headers()
        redirect = ThreadingHTTPServer(("127.0.0.1", 0), Redirect)
        thread = threading.Thread(target=redirect.serve_forever, daemon=True)
        thread.start()
        try:
            with self.assertRaises(HTTPError) as error:
                build_opener(NoRedirect()).open(f"http://127.0.0.1:{redirect.server_address[1]}/start", timeout=2)
            self.assertEqual(error.exception.code, 302)
            self.assertEqual(hits, ["/start"])
        finally:
            redirect.shutdown(); redirect.server_close(); thread.join()

    def test_proxy_injects_own_key_without_leaking_code_in_result(self):
        self.save()
        response = Mock()
        response.__enter__ = Mock(return_value=response)
        response.__exit__ = Mock(return_value=False)
        response.headers = Message()
        response.headers["Content-Type"] = "application/json"
        response.read.return_value = b'{"status":"1","pois":[]}'
        captured = {}
        def open_request(request, timeout):
            captured["url"] = request.full_url
            response.geturl.return_value = request.full_url
            return response
        with patch("amap_config.build_opener") as opener:
            opener.return_value.open.side_effect = open_request
            data, mime = self.config.proxy("/v3/place/text", "keywords=Shanghai&key=attacker&jscode=override")
        parsed = urlsplit(captured["url"])
        self.assertEqual(parsed.netloc, "restapi.amap.com")
        query = parse_qs(parsed.query)
        self.assertEqual(query["key"], [TEST_KEY])
        self.assertEqual(query["jscode"], [TEST_CODE])
        self.assertNotIn(TEST_CODE.encode(), data)
        self.assertTrue(mime.startswith("application/json"))


class HttpMapTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.config = AmapConfig(cls.temp.name)
        cls.control = Mock()
        cls.server = make_server(controller=cls.control, amap=cls.config)
        cls.port = cls.server.server_address[1]
        cls.origin = f"http://127.0.0.1:{cls.port}"
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close(); cls.thread.join(); cls.temp.cleanup()

    def req(self, path, body=None, extra=None, auth=True):
        headers = {"Origin": self.origin}
        if auth: headers["X-Local-Token"] = self.server.token
        if body is not None: headers["Content-Type"] = "application/json"
        headers.update(extra or {})
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=3)
        conn.request("GET" if body is None else "POST", path, json.dumps(body) if body is not None else None, headers)
        response = conn.getresponse()
        result = response.status, response.read(), dict(response.getheaders())
        conn.close(); return result

    def test_credentials_require_parent_session(self):
        self.assertEqual(self.req("/api/amap/config", auth=False)[0], 403)
        self.assertEqual(self.req("/api/amap/bootstrap", extra={"Origin":"null"})[0], 403)
        self.assertEqual(self.req("/api/amap/config", {"key":TEST_KEY,"security_code":TEST_CODE}, auth=False)[0], 403)

    def test_config_bootstrap_keeps_security_code_server_side(self):
        old_token = self.server.map_token
        status, body, _ = self.req("/api/amap/config", {"key":TEST_KEY,"security_code":TEST_CODE})
        self.assertEqual(status, 200)
        self.assertNotIn(TEST_CODE.encode(), body)
        self.assertNotEqual(self.server.map_token, old_token)
        status, body, _ = self.req("/api/amap/bootstrap")
        self.assertEqual(status, 200)
        data = json.loads(body)
        self.assertEqual(data["key"], TEST_KEY)
        self.assertNotIn(TEST_CODE.encode(), body)
        self.assertTrue(data["serviceHost"].endswith("/_AMapService"))
        self.control.launch.assert_not_called()
        self.control.stop.assert_not_called()

    def test_only_map_frame_policy_allows_remote_scripts(self):
        _, body, headers = self.req("/")
        self.assertIn(b'sandbox="allow-scripts allow-popups"', body)
        self.assertNotIn("unsafe-eval", headers["Content-Security-Policy"])
        _, _, headers = self.req("/amap-picker.html")
        self.assertIn("https://*.amap.com", headers["Content-Security-Policy"])
        self.assertIn("frame-ancestors 'self'", headers["Content-Security-Policy"])

    def test_opaque_frame_can_get_public_asset_not_device_api(self):
        extra = {"Origin":"null", "Sec-Fetch-Site":"cross-site"}
        self.assertEqual(self.req("/amap-frame.js", extra=extra, auth=False)[0], 200)
        self.assertEqual(self.req("/api/session", extra=extra, auth=False)[0], 403)
        self.assertEqual(self.req("/api/start", {}, extra=extra)[0], 403)

    def test_proxy_scoped_token_and_path(self):
        path = "/amap-proxy/wrong/_AMapService/v3/place/text"
        self.assertEqual(self.req(path, extra={"Origin":"null"}, auth=False)[0], 403)
        prefix = "/amap-proxy/" + self.server.map_token + "/_AMapService"
        self.assertEqual(self.req(prefix + "/api/start", extra={"Origin":"null"}, auth=False)[0], 400)
        with patch.object(self.config, "proxy", return_value=(b'{"pois":[]}',"application/json")):
            status, _, headers = self.req(prefix + "/v3/place/text", extra={"Origin":"null"}, auth=False)
            self.assertEqual(status,200)
            self.assertEqual(headers["Access-Control-Allow-Origin"], "null")
        with patch.object(self.config, "proxy", side_effect=RuntimeError("url contains " + TEST_CODE)):
            status, body, _ = self.req(prefix + "/v3/place/text", extra={"Origin":"null"}, auth=False)
            self.assertEqual(status,502)
            self.assertNotIn(TEST_CODE.encode(),body)


if __name__ == "__main__":
    unittest.main(verbosity=2)
