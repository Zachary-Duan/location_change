const assert = require('node:assert/strict');
const test = require('node:test');
const {wgsToGcj, gcjToWgs, parsePair} = require('./dist/coordinates.js');
test('known Beijing formula reference and inverse', () => {
  const projected = wgsToGcj(116.404,39.915);
  assert.ok(Math.abs(projected[0]-116.41024449916938)<1e-9);
  assert.ok(Math.abs(projected[1]-39.91640428150164)<1e-9);
  const result=gcjToWgs(116.41024449916938,39.91640428150164);
  assert.ok(Math.abs(result.lng-116.404)<1e-7);
  assert.ok(Math.abs(result.lat-39.915)<1e-7);
  assert.equal(result.converted,true);
});
test('inverse preserves longitude/latitude order across mainland samples', () => {
  for(const [lng,lat] of [[121.4737,31.2304],[114.0579,22.5431],[104.0665,30.5728]]) {
    const result=gcjToWgs(...wgsToGcj(lng,lat));
    assert.ok(Math.abs(lng-result.lng)<1e-7 && Math.abs(lat-result.lat)<1e-7);
  }
});
test('explicit opt-out does not convert nearby foreign regions', () => {
  assert.deepEqual(gcjToWgs(126.978,37.5665,false),{lng:126.978,lat:37.5665,converted:false});
  assert.deepEqual(gcjToWgs(151.2093,-33.8688),{lng:151.2093,lat:-33.8688,converted:false});
  assert.deepEqual(gcjToWgs(0,0),{lng:0,lat:0,converted:false});
});
test('paste parsing uses longitude first, supports Chinese comma and negative values', () => {
  assert.deepEqual(parsePair(' 121.49，31.24 '),{lng:121.49,lat:31.24});
  assert.deepEqual(parsePair('-74.05,40.69'),{lng:-74.05,lat:40.69});
});
test('invalid and unsafe coordinate strings rejected', () => {
  for(const value of ['', '31.2,121.4','NaN,Infinity','1;alert(1),2','180.1,20']) assert.throws(()=>parsePair(value));
  assert.throws(()=>gcjToWgs(NaN,20));assert.throws(()=>gcjToWgs(100,91));
});
