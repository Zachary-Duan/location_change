"""Local AMap credentials and a narrowly scoped proxy, separate from device control."""
import json
import os
from pathlib import Path
import re
import tempfile
import threading
from urllib.parse import parse_qsl, urlencode
from urllib.request import HTTPRedirectHandler, Request, build_opener

UPSTREAM_PATHS = {"/v3/place/text", "/v3/geocode/regeo", "/v3/geocode/geo", "/v3/assistant/inputtips", "/v4/map/styles"}


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def credential(value, label):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_-]{16,128}", value.strip()):
        raise ValueError(f"{label} 格式不正确，请从高德控制台完整复制。")
    return value.strip()


class AmapConfig:
    def __init__(self, directory=None):
        self.directory = Path(directory or os.environ.get("LOCATION_STATE_DIR", str(Path(__file__).parent / ".runtime")))
        self.path = self.directory / "amap.json"
        self.lock = threading.RLock()
        self.slots = threading.BoundedSemaphore(4)

    def read(self):
        with self.lock:
            try:
                value = json.loads(self.path.read_text())
                return {"key": credential(value.get("key"), "Key"), "security_code": credential(value.get("security_code"), "安全密钥")}
            except (OSError, ValueError, AttributeError):
                return None

    def status(self):
        value = self.read()
        return {"configured": value is not None, "key_hint": value["key"][:4] + "…" + value["key"][-4:] if value else ""}

    def save(self, body):
        value = {"key": credential(body.get("key"), "Key"), "security_code": credential(body.get("security_code"), "安全密钥")}
        with self.lock:
            self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
            name = None
            try:
                with tempfile.NamedTemporaryFile(mode="w", dir=self.directory, prefix=".amap-", delete=False) as output:
                    name = output.name
                    # Windows uses the containing user's directory ACL; fchmod is Unix-only.
                    if hasattr(os, "fchmod"):
                        os.fchmod(output.fileno(), 0o600)
                    json.dump(value, output)
                os.replace(name, self.path)
            finally:
                if name and os.path.exists(name):
                    os.unlink(name)
        return self.status()

    def clear(self):
        with self.lock:
            self.path.unlink(missing_ok=True)
        return self.status()

    def proxy(self, path, query):
        if path not in UPSTREAM_PATHS or len(query) > 8192:
            raise ValueError("不支持此地图请求。")
        value = self.read()
        if value is None:
            raise ValueError("尚未配置高德地图。")
        # The client cannot choose an upstream host or override either credential.
        pairs = [(k, v) for k, v in parse_qsl(query, keep_blank_values=True, max_num_fields=64) if k.lower() not in ("key", "jscode", "securityjscode")]
        pairs += [("key", value["key"]), ("jscode", value["security_code"])]
        host = "https://webapi.amap.com" if path == "/v4/map/styles" else "https://restapi.amap.com"
        url = host + path + "?" + urlencode(pairs)
        if not self.slots.acquire(blocking=False):
            raise ValueError("地图请求较多，请稍后再试。")
        try:
            request = Request(url, headers={"User-Agent": "iPhone-Location-Local/1.0", "Accept": "application/json, application/javascript"})
            with build_opener(NoRedirect()).open(request, timeout=10) as response:
                # Do not follow API redirects to a different origin or path.
                if response.geturl() != url:
                    raise ValueError("地图接口返回了非预期地址。")
                data = response.read(2 * 1024 * 1024 + 1)
                if len(data) > 2 * 1024 * 1024:
                    raise ValueError("地图响应过大。")
                content_type = response.headers.get_content_type()
                if content_type not in ("application/json", "application/javascript", "text/javascript", "text/plain"):
                    raise ValueError("地图接口返回了非预期内容。")
                return data, "application/javascript; charset=utf-8" if any(k == "callback" for k, _ in pairs) else "application/json; charset=utf-8"
        finally:
            self.slots.release()
