"""No device mutations: HTTP boundary and controller state semantics."""
import http.client
import io
import json
import threading
import unittest
from unittest.mock import Mock, patch

from server import Controller, coordinates, make_server


class CoordinatesTest(unittest.TestCase):
    def test_accepts_zero_negative_and_boundaries(self):
        self.assertEqual(coordinates({"latitude": 0, "longitude": -180}), [0., -180.])
        self.assertEqual(coordinates({"latitude": -90, "longitude": 180}), [-90., 180.])

    def test_rejects_invalid_values(self):
        for value in (None, True, "31", "", float("nan"), float("inf"), 91):
            with self.subTest(value=value), self.assertRaises(ValueError):
                coordinates({"latitude": value, "longitude": 10})
        with self.assertRaises(ValueError):
            coordinates({"latitude": 10, "longitude": -181})


class ControllerTest(unittest.TestCase):
    def test_invalid_device_never_spawns(self):
        with patch("server.worker") as spawn:
            with self.assertRaises(ValueError):
                Controller().launch("set", {"device_id": "unknown", "latitude": 1, "longitude": 2})
            spawn.assert_not_called()

    def test_invalid_coordinate_never_spawns(self):
        control = Controller()
        control.devices = [{"id": "test"}]
        with patch("server.worker") as spawn:
            with self.assertRaises(ValueError):
                control.launch("set", {"device_id": "test", "latitude": True, "longitude": 2})
            spawn.assert_not_called()

    def test_alive_process_is_not_success(self):
        control = Controller()
        control.process = Mock()
        control.state["phase"] = "connecting"
        self.assertEqual(control.snapshot()["phase"], "connecting")
        with self.assertRaises(ValueError):
            control.launch("prepare", {"device_id": "test"})

    def consume(self, events, action="set"):
        control = Controller()
        proc = Mock(stdout=io.StringIO("".join(json.dumps(x) + "\n" for x in events)), stdin=io.StringIO())
        control.process = proc
        control.state["phase"] = "connecting"
        control._watch(proc, action)
        self.assertIsNone(control.process)
        return control.snapshot()

    def test_silent_exit_is_failure(self):
        self.assertEqual(self.consume([])["phase"], "error")

    def test_disconnect_after_ack_is_unknown(self):
        state = self.consume([{"event": "sent", "acknowledged": True}, {"event": "error", "message": "连接中断"}])
        self.assertEqual(state["phase"], "error")
        self.assertIn("待确认", state["message"])

    def test_clear_is_only_sent_not_verified(self):
        state = self.consume([{"event": "cleared"}])
        self.assertEqual(state["phase"], "stopped")
        self.assertIn("指令已发送", state["message"])
        self.assertIn("请在手机上确认", state["message"])

    def test_cancel_does_not_claim_simulation(self):
        state = self.consume([{"event": "cancelled"}])
        self.assertEqual(state["phase"], "cancelled")
        self.assertIn("未发送", state["message"])

    def test_stop_uses_same_device(self):
        control = Controller()
        control.process = Mock()
        control.state.update(phase="sent", device_id="first")
        with self.assertRaises(ValueError):
            control.stop({"device_id": "second"})
        control.process.stdin.write.assert_not_called()


class HttpTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.control = Mock()
        cls.control.snapshot.return_value = {"phase": "idle"}
        cls.server = make_server(controller=cls.control)
        cls.port = cls.server.server_address[1]
        cls.origin = f"http://127.0.0.1:{cls.port}"
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()

    def request(self, method, path, headers=None, body=None):
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=3)
        conn.request(method, path, body, headers or {})
        response = conn.getresponse()
        status, data, response_headers = response.status, response.read(), dict(response.getheaders())
        conn.close()
        return status, data, response_headers

    def test_ui_serves_with_csp(self):
        status, data, headers = self.request("GET", "/")
        self.assertEqual(status, 200)
        self.assertIn("iPhone 定位".encode(), data)
        self.assertIn("frame-ancestors 'none'", headers["Content-Security-Policy"])

    def test_wrong_host_and_cross_site_bootstrap_blocked(self):
        self.assertEqual(self.request("GET", "/api/session", {"Host": "example.com"})[0], 403)
        self.assertEqual(self.request("GET", "/api/session", {"Sec-Fetch-Site": "cross-site"})[0], 403)

    def test_public_link_can_open_homepage_only(self):
        headers = {"Sec-Fetch-Site": "cross-site", "Sec-Fetch-Mode": "navigate", "Sec-Fetch-Dest": "document"}
        self.assertEqual(self.request("GET", "/", headers)[0], 200)
        self.assertEqual(self.request("GET", "/api/session", headers)[0], 403)
        self.assertEqual(self.request("GET", "/", {**headers, "Host": "example.com"})[0], 403)

    def test_public_fetch_and_iframe_cannot_open_homepage(self):
        headers = {"Sec-Fetch-Site": "cross-site", "Sec-Fetch-Mode": "navigate", "Sec-Fetch-Dest": "document"}
        self.assertEqual(self.request("GET", "/", {**headers, "Sec-Fetch-Mode": "cors"})[0], 403)
        self.assertEqual(self.request("GET", "/", {**headers, "Sec-Fetch-Dest": "iframe"})[0], 403)

    def test_openmap_search_is_token_protected(self):
        self.assertEqual(self.request("GET", "/api/openmap/search?q=Beijing")[0], 403)
        with patch.object(self.server.openmap, "search", return_value={"results": []}) as search:
            self.assertEqual(self.request("GET", "/api/openmap/search?q=Beijing", {"X-Local-Token": self.server.token})[0], 200)
            search.assert_called_once_with("Beijing")
        self.assertEqual(self.request("GET", "/api/openmap/search?q=Beijing", {"X-Local-Token": self.server.token, "Sec-Fetch-Site": "cross-site"})[0], 403)

    def test_status_requires_session_token(self):
        self.assertEqual(self.request("GET", "/api/status")[0], 403)
        self.assertEqual(self.request("GET", "/api/status", {"X-Local-Token": self.server.token})[0], 200)

    def test_cross_origin_post_blocked_even_with_token(self):
        headers = {"X-Local-Token": self.server.token, "Content-Type": "application/json", "Origin": "https://example.com"}
        self.assertEqual(self.request("POST", "/api/start", headers, "{}")[0], 403)

    def test_missing_origin_blocked(self):
        headers = {"X-Local-Token": self.server.token, "Content-Type": "application/json"}
        self.assertEqual(self.request("POST", "/api/start", headers, "{}")[0], 403)

    def test_non_object_and_oversized_json_rejected(self):
        headers = {"X-Local-Token": self.server.token, "Content-Type": "application/json", "Origin": self.origin}
        self.assertEqual(self.request("POST", "/api/start", headers, "[]")[0], 400)
        self.assertEqual(self.request("POST", "/api/start", headers, "x" * 4097)[0], 400)

    def test_arbitrary_files_not_served(self):
        self.assertEqual(self.request("GET", "/../device_worker.py")[0], 404)
        self.assertEqual(self.request("GET", "/.runtime/")[0], 404)


if __name__ == "__main__":
    unittest.main(verbosity=2)
