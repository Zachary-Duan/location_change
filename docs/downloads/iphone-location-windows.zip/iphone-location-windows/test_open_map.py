import io
import json
import unittest
from unittest.mock import Mock, patch
from open_map import OpenMapSearch


class OpenMapTest(unittest.TestCase):
    def setUp(self):
        self.searcher = OpenMapSearch()
        self.searcher.opener = Mock()

    def response(self, features):
        self.searcher.opener.open.return_value = io.BytesIO(json.dumps({'features': features}).encode())

    def test_bounded_search_returns_wgs84_and_reuses_cache(self):
        self.response([{'geometry': {'type': 'Point', 'coordinates': [116.4, 39.9]}, 'properties': {'name': '测试地点', 'city': '北京'}}])
        value = self.searcher.search('北京测试')
        self.assertEqual(value['results'][0], {'lng': 116.4, 'lat': 39.9, 'label': '测试地点 · 北京'})
        self.assertEqual(self.searcher.search('北京测试'), value)
        self.assertEqual(self.searcher.opener.open.call_count, 1)
        request = self.searcher.opener.open.call_args.args[0]
        self.assertTrue(request.full_url.startswith('https://photon.komoot.io/api/?'))
        self.assertIn('iPhoneLocationConsole', request.get_header('User-agent'))
        with self.assertRaisesRegex(ValueError, '搜索太快'):
            self.searcher.search('另一个地点')

    def test_invalid_query_never_requests_network(self):
        for query in ('', 'a', 'x' * 121, None):
            with self.assertRaises(ValueError): self.searcher.search(query)
        self.searcher.opener.open.assert_not_called()

    def test_invalid_coordinates_are_discarded(self):
        self.response([{'geometry': {'type': 'Point', 'coordinates': c}, 'properties': {}} for c in ([181, 0], [True, 1], [0, 91], ['1', 0])])
        self.assertEqual(self.searcher.search('无效坐标'), {'results': []})

    def test_oversized_response_rejected_and_lock_released(self):
        self.searcher.opener.open.return_value = io.BytesIO(b'x' * 262145)
        with self.assertRaises(ValueError): self.searcher.search('大响应')
        self.assertFalse(self.searcher.lock.locked())

if __name__ == '__main__': unittest.main()
