"""Low-volume, explicit OpenStreetMap place search through Photon's public API."""
import json
import math
import threading
import time
from urllib.parse import urlencode
from urllib.request import HTTPRedirectHandler, Request, build_opener


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class OpenMapSearch:
    def __init__(self):
        self.lock = threading.Lock()
        self.cache = {}
        self.last_request = float('-inf')
        self.opener = build_opener(NoRedirect())

    def search(self, query):
        if not isinstance(query, str) or not 2 <= len(query.strip()) <= 120:
            raise ValueError('请输入 2 至 120 个字符的城市、地址或地点。')
        query = query.strip()
        if not self.lock.acquire(blocking=False):
            raise ValueError('正在搜索，请稍候再试。')
        try:
            now = time.monotonic()
            cached = self.cache.get(query)
            if cached and now - cached[0] < 600:
                return cached[1]
            if now - self.last_request < 1.5:
                raise ValueError('搜索太快，请稍候再试。')
            self.last_request = now
            request = Request('https://photon.komoot.io/api/?' + urlencode({'q': query, 'limit': 6}),
                              headers={'User-Agent': 'iPhoneLocationConsole/2.0 (+https://iphone-location-console.zhangyilan.chatgpt.site)', 'Accept': 'application/json'})
            with self.opener.open(request, timeout=8) as response:
                raw = response.read(262145)
            if len(raw) > 262144:
                raise ValueError('搜索结果过大，请缩小搜索范围。')
            payload = json.loads(raw)
            results = []
            for feature in payload.get('features', [])[:6]:
                geometry = feature.get('geometry', {})
                values = geometry.get('coordinates', [])
                if geometry.get('type') != 'Point' or not isinstance(values, list) or len(values) < 2:
                    continue
                lng, lat = values[:2]
                if any(isinstance(x, bool) or not isinstance(x, (float, int)) or not math.isfinite(x) for x in (lng, lat)) or abs(lng) > 180 or abs(lat) > 90:
                    continue
                props = feature.get('properties', {})
                parts = [str(props[k])[:160] for k in ('name', 'street', 'housenumber', 'city', 'state', 'country') if props.get(k)]
                label = ' · '.join(dict.fromkeys(parts))[:250] or query
                results.append({'lng': lng, 'lat': lat, 'label': label})
            result = {'results': results}
            if len(self.cache) >= 64:
                self.cache.pop(next(iter(self.cache)))
            self.cache[query] = (now, result)
            return result
        finally:
            self.lock.release()
