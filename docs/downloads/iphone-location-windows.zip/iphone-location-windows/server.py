"""Loopback-only browser controller for a single explicitly selected USB iPhone."""
import argparse
import errno
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import math
from pathlib import Path
import secrets
import signal
import subprocess
import sys
import threading
import time
import webbrowser
from urllib.parse import urlsplit, parse_qs
from amap_config import AmapConfig
from open_map import OpenMapSearch

ROOT = Path(__file__).resolve().parent


def coordinates(body):
    values = []
    for key, limit in (("latitude", 90), ("longitude", 180)):
        value = body.get(key)
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or abs(value) > limit:
            raise ValueError("请输入有效经纬度：纬度 −90 至 90，经度 −180 至 180。")
        values.append(float(value))
    return values


def worker(action, *args):
    process_options = ({"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP}
                       if sys.platform == "win32" else {"start_new_session": True})
    return subprocess.Popen([sys.executable, "-u", str(ROOT / "device_worker.py"), action, *map(str, args)],
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                            text=True, encoding="utf-8", bufsize=1, **process_options)


class Controller:
    def __init__(self):
        self.lock = threading.RLock()
        self.discovery_lock = threading.Lock()
        self.devices = []
        self.process = None
        self.state = {"phase": "idle", "message": "连接设备后即可发送位置。网页不会自动修改定位。", "device_id": None}

    def snapshot(self):
        with self.lock:
            return dict(self.state)

    def discover(self):
        with self.discovery_lock:
            process = worker("list")
            try:
                stdout, _ = process.communicate(timeout=24)
            except subprocess.TimeoutExpired:
                process.kill()
                process.communicate()
                raise ValueError("读取设备超时，请检查数据线和手机解锁状态。")
            result = None
            for line in stdout.splitlines():
                try:
                    event = json.loads(line)
                except ValueError:
                    continue
                if event.get("event") == "error":
                    raise ValueError(event["message"])
                if event.get("event") == "devices":
                    result = event["devices"]
            if result is None or process.returncode:
                raise ValueError("设备连接库未能读取设备，请检查安装和访问权限。")
            with self.lock:
                self.devices = result
            return result

    def launch(self, action, body):
        udid = body.get("device_id")
        if not isinstance(udid, str):
            raise ValueError("请先选择连接的 iPhone。")
        coords = coordinates(body) if action == "set" else []
        with self.lock:
            if self.process is not None:
                raise ValueError("正在处理上一项操作，请先停止模拟或等待准备完成。")
            if not any(d["id"] == udid for d in self.devices):
                raise ValueError("所选设备不在连接列表中，请刷新设备。")
            phase = {"set": "connecting", "prepare": "preparing", "clear": "stopping"}[action]
            message = {"set": "正在连接手机并发送目标坐标…", "prepare": "正在准备开发者连接，首次可能需要下载支持文件…", "clear": "正在重新连接手机并发送停止指令…"}[action]
            self.state = {"phase": phase, "message": message, "device_id": udid}
            if coords:
                self.state.update(latitude=coords[0], longitude=coords[1])
            process = worker(action, udid, *coords)
            self.process = process
            threading.Thread(target=self._watch, args=(process, action), daemon=True).start()
            threading.Thread(target=self._deadline, args=(process, 240 if action == "prepare" else 65, {phase}), daemon=True).start()
            return dict(self.state)

    def _watch(self, process, action):
        terminal_event = False
        for line in process.stdout:
            try:
                event = json.loads(line)
            except ValueError:
                continue
            with self.lock:
                if self.process is not process:
                    continue
                kind = event.get("event")
                if kind == "sent":
                    # A user can request stop while the transport is still being acquired.
                    if self.state["phase"] != "stopping":
                        self.state.update(phase="sent", message="设备已接受模拟定位指令。请在目标 App 中检查实际位置。" if event.get("acknowledged") else "模拟定位指令已发送。请在目标 App 中检查实际位置。")
                elif kind == "cleared":
                    terminal_event = True
                    self.state.update(phase="stopped", message="停止指令已发送。请在手机上确认已恢复真实位置；如未恢复，可重启 iPhone 后检查。")
                elif kind == "prepared":
                    terminal_event = True
                    self.state.update(phase="ready", message="开发者支持文件已准备。可以在地图选点并开始模拟。")
                elif kind == "cancelled":
                    terminal_event = True
                    self.state.update(phase="cancelled", message="已取消本次操作，未发送本次目标坐标。")
                elif kind == "error":
                    terminal_event = True
                    self.state.update(phase="error", message=event.get("message", "设备操作失败。") + (" 定位状态待确认，可重新连接后停止模拟。" if action in ("set", "clear") else ""))
        process.wait()
        with self.lock:
            if self.process is process:
                if not terminal_event:
                    self.state.update(phase="error", message="连接程序已退出，手机定位状态待确认。请重新连接后停止模拟。")
                self.process = None
        for stream in (process.stdout, process.stdin):
            if stream:
                stream.close()

    def _deadline(self, process, seconds, phases):
        # Wake promptly when this process ends; a held successful session is not timed out.
        until = time.monotonic() + seconds
        while time.monotonic() < until:
            if process.poll() is not None:
                return
            time.sleep(.3)
        with self.lock:
            if self.process is process and self.state["phase"] in phases:
                self.state.update(phase="error", message="操作超时，手机定位状态待确认。请检查连接后重试；若曾发送坐标，重新连接后停止模拟。")
                process.kill()

    def stop(self, body):
        with self.lock:
            process = self.process
            if process is None:
                return self.launch("clear", body)
            if self.state["phase"] == "preparing":
                raise ValueError("设备准备尚未完成，请等待后再操作。")
            if self.state["phase"] == "stopping":
                return dict(self.state)
            if body.get("device_id") != self.state.get("device_id"):
                raise ValueError("请停止当前会话对应的 iPhone。")
            self.state.update(phase="stopping", message="正在发送停止模拟指令…")
            try:
                process.stdin.write("stop\n")
                process.stdin.flush()
            except (BrokenPipeError, OSError, ValueError):
                self.state.update(phase="error", message="连接已经中断。请刷新设备，重新连接后停止模拟。")
            threading.Thread(target=self._deadline, args=(process, 65, {"stopping"}), daemon=True).start()
            return dict(self.state)

    def shutdown(self):
        with self.lock:
            process = self.process
            if not process:
                return
            try:
                process.stdin.write("stop\n")
                process.stdin.flush()
            except (OSError, ValueError):
                pass
        try:
            process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
            print("连接已结束，未确认恢复定位。请在 iPhone 上检查，必要时重启。", flush=True)


class Handler(BaseHTTPRequestHandler):
    server_version = "LocalLocation/1.0"

    def setup(self):
        super().setup()
        self.connection.settimeout(12)

    def log_message(self, *_):
        pass

    def reply(self, status, data, content_type="application/json; charset=utf-8", map_proxy=False):
        raw = json.dumps(data, ensure_ascii=False).encode() if not isinstance(data, bytes) else data
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if self.path == "/amap-picker.html":
            local = "http://" + self.headers["Host"]
            remote = "https://*.amap.com https://*.autonavi.com"
            self.send_header("Referrer-Policy", "strict-origin-when-cross-origin")
            self.send_header("Content-Security-Policy", f"default-src 'none'; script-src {local} {remote} 'unsafe-eval'; style-src {local} {remote} 'unsafe-inline'; connect-src {local} {remote}; img-src {local} {remote} data: blob:; worker-src blob:; font-src {local} {remote} data:; frame-ancestors 'self'; base-uri 'none'; form-action 'none'")
        elif self.path == "/openmap-picker.html":
            local = "http://" + self.headers["Host"]
            self.send_header("Referrer-Policy", "strict-origin-when-cross-origin")
            self.send_header("Content-Security-Policy", f"default-src 'none'; script-src {local}; style-src {local} 'unsafe-inline'; img-src {local} https://tile.openstreetmap.org data:; frame-ancestors 'self'; base-uri 'none'; form-action 'none'")
        else:
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; frame-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        if map_proxy or self.path in ("/amap-frame.js", "/amap-frame.css", "/openmap-frame.js", "/openmap-frame.css", "/vendor/leaflet.js", "/vendor/leaflet.css"):
            self.send_header("Access-Control-Allow-Origin", "null")
        self.end_headers()
        try:
            self.wfile.write(raw)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def allowed(self, token=True, mutation=False):
        host = self.headers.get("Host", "")
        origin = "http://" + host
        public_entry = (self.command == "GET" and self.path == "/"
                        and self.headers.get("Sec-Fetch-Mode") == "navigate"
                        and self.headers.get("Sec-Fetch-Dest") == "document")
        if host not in self.server.allowed_hosts or (self.headers.get("Sec-Fetch-Site") == "cross-site" and not public_entry):
            self.reply(403, {"error": "只允许本机同源访问。"})
            return False
        supplied_origin = self.headers.get("Origin")
        if (mutation and supplied_origin != origin) or (supplied_origin and supplied_origin != origin):
            self.reply(403, {"error": "请求来源不匹配。请重新打开本地控制台。"})
            return False
        if token and not hmac.compare_digest(self.headers.get("X-Local-Token", "").encode(), self.server.token.encode()):
            self.reply(403, {"error": "会话已失效，请刷新页面。"})
            return False
        return True

    def do_GET(self):
        if self.path.startswith("/amap-proxy/"):
            self.map_proxy()
            return
        # Public, credential-free assets for an opaque-origin sandboxed map frame.
        if self.path in ("/amap-frame.js", "/amap-frame.css", "/openmap-frame.js", "/openmap-frame.css", "/vendor/leaflet.js", "/vendor/leaflet.css"):
            if self.headers.get("Host") not in self.server.allowed_hosts:
                self.reply(403, {"error": "Invalid host"})
                return
            filename = self.path[1:]
            self.reply(200, (ROOT / "dist" / filename).read_bytes(), "text/javascript; charset=utf-8" if filename.endswith(".js") else "text/css; charset=utf-8")
            return
        if not self.allowed(token=self.path.startswith("/api/") and self.path != "/api/session"):
            return
        if self.path == "/api/session":
            self.reply(200, {"token": self.server.token})
        elif self.path == "/api/status":
            self.reply(200, self.server.controller.snapshot())
        elif self.path == "/api/amap/config":
            self.reply(200, self.server.amap.status())
        elif self.path == "/api/amap/bootstrap":
            value = self.server.amap.read()
            if value is None:
                self.reply(400, {"error": "请先填写高德 Key 和安全密钥。"})
            else:
                self.reply(200, {"key": value["key"], "serviceHost": "http://" + self.headers["Host"] + "/amap-proxy/" + self.server.map_token + "/_AMapService"})
        elif urlsplit(self.path).path == "/api/openmap/search":
            try:
                query = parse_qs(urlsplit(self.path).query, max_num_fields=2).get("q", [""])[0]
                self.reply(200, self.server.openmap.search(query))
            except ValueError as error:
                self.reply(400, {"error": str(error)})
            except Exception:
                self.reply(502, {"error": "免配置搜索暂时不可用，请稍后重试，或直接点击地图选点。"})
        elif self.path == "/api/devices":
            try:
                self.reply(200, {"devices": self.server.controller.discover()})
            except ValueError as error:
                self.reply(503, {"error": str(error)})
        else:
            assets = {"/": ("index.html", "text/html; charset=utf-8"), "/app.js": ("app.js", "text/javascript; charset=utf-8"), "/style.css": ("style.css", "text/css; charset=utf-8"), "/favicon.svg": ("favicon.svg", "image/svg+xml"), "/coordinates.js": ("coordinates.js", "text/javascript; charset=utf-8"), "/amap-controller.js": ("amap-controller.js", "text/javascript; charset=utf-8"), "/amap-picker.html": ("amap-picker.html", "text/html; charset=utf-8")}
            assets["/openmap-picker.html"] = ("openmap-picker.html", "text/html; charset=utf-8")
            if self.path not in assets:
                self.reply(404, {"error": "Not found"})
                return
            name, mime = assets[self.path]
            self.reply(200, (ROOT / "dist" / name).read_bytes(), mime)

    def map_proxy(self):
        parsed = urlsplit(self.path)
        parts = parsed.path[len("/amap-proxy/"):].split("/_AMapService", 1)
        if self.headers.get("Host") not in self.server.allowed_hosts or len(parts) != 2 or not hmac.compare_digest(parts[0].encode(), self.server.map_token.encode()):
            self.reply(403, {"error": "地图会话已失效，请重新加载。"}, map_proxy=True)
            return
        try:
            data, mime = self.server.amap.proxy(parts[1], parsed.query)
            self.reply(200, data, mime, map_proxy=True)
        except ValueError as error:
            self.reply(400, {"error": str(error)}, map_proxy=True)
        except Exception:
            # Upstream URLs contain credentials; never reflect network exception text.
            self.reply(502, {"error": "高德服务暂时不可用，请检查网络和凭据。"}, map_proxy=True)

    def do_POST(self):
        if not self.allowed(mutation=True):
            return
        if self.path not in ("/api/start", "/api/stop", "/api/prepare", "/api/amap/config", "/api/amap/clear"):
            self.reply(404, {"error": "Not found"})
            return
        try:
            if self.headers.get("Content-Type", "").split(";")[0] != "application/json":
                raise ValueError("只接受 JSON 请求。")
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 4096 or self.headers.get("Transfer-Encoding"):
                raise ValueError("请求大小不正确。")
            body = json.loads(self.rfile.read(length))
            if not isinstance(body, dict):
                raise ValueError("请求格式不正确。")
            if self.path in ("/api/amap/config", "/api/amap/clear"):
                result = self.server.amap.save(body) if self.path.endswith("config") else self.server.amap.clear()
                self.server.map_token = secrets.token_urlsafe(32)
                self.reply(200, result)
                return
            control = self.server.controller
            result = control.stop(body) if self.path == "/api/stop" else control.launch("set" if self.path == "/api/start" else "prepare", body)
            self.reply(202, result)
        except (ValueError, UnicodeError) as error:
            self.reply(400, {"error": str(error)})
        except OSError:
            self.reply(500, {"error": "本机操作失败，请检查本地目录权限与可用空间后重试。"})


def make_server(port=0, controller=None, amap=None):
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    server.daemon_threads = True
    server.controller = controller or Controller()
    server.token = secrets.token_urlsafe(32)
    server.map_token = secrets.token_urlsafe(32)
    server.amap = amap or AmapConfig()
    server.openmap = OpenMapSearch()
    actual_port = server.server_address[1]
    server.allowed_hosts = {f"127.0.0.1:{actual_port}", f"localhost:{actual_port}"}
    return server


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--open", action="store_true")
    args = parser.parse_args()
    try:
        server = make_server(args.port)
    except OSError as error:
        if error.errno != errno.EADDRINUSE or args.port != 8765:
            raise
        print("常用端口已被占用，正在为本次控制台分配其他本机地址。", flush=True)
        server = make_server(0)
    url = f"http://127.0.0.1:{server.server_address[1]}/"
    print(f"iPhone 定位控制台：{url}\n保持此窗口开启；退出前请点击停止模拟。", flush=True)
    if args.open:
        webbrowser.open(url)
    def exit_signal(*_):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, exit_signal)
    try:
        server.serve_forever(poll_interval=.3)
    except KeyboardInterrupt:
        pass
    finally:
        server.controller.shutdown()
        server.server_close()


if __name__ == "__main__":
    main()
