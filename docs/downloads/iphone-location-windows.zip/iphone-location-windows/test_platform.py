"""Cross-platform process regression tests, without importing device transports."""
import asyncio
from contextlib import AsyncExitStack
from importlib.util import find_spec
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import AsyncMock, Mock, patch

import device_worker
from amap_config import AmapConfig
import server


class WindowsControlTest(unittest.IsolatedAsyncioTestCase):
    async def test_stop_and_eof_over_plain_pipe(self):
        for data in (b'ignored\nstop\n', b''):
            with self.subTest(data=data):
                read_fd, write_fd = os.pipe()
                stop = asyncio.Event()
                try:
                    if data:
                        os.write(write_fd, data)
                    os.close(write_fd)
                    with patch.object(sys, 'platform', 'win32'), patch.object(sys, 'stdin', Mock(fileno=lambda:read_fd)):
                        await asyncio.wait_for(device_worker.read_control(stop), 2)
                    self.assertTrue(stop.is_set())
                finally:
                    os.close(read_fd)

    async def test_cancel_with_pending_read_does_not_wait_for_executor(self):
        # The child must exit while its input is still open and no stop was sent.
        source = '''import asyncio, sys
import device_worker
async def test():
    sys.platform = 'win32'
    task = asyncio.create_task(device_worker.read_control(asyncio.Event()))
    await asyncio.sleep(.03)
    task.cancel()
    await asyncio.gather(task, return_exceptions=True)
asyncio.run(test())
print('exited', flush=True)
'''
        child = subprocess.Popen([sys.executable, '-c', source], cwd=Path(__file__).parent,
                                 stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            self.assertEqual(child.wait(timeout=5), 0)
            self.assertIn(b'exited', child.stdout.read())
        finally:
            if child.poll() is None:
                child.kill(); child.wait()
            for stream in (child.stdin, child.stdout, child.stderr):
                stream.close()


@unittest.skipUnless(find_spec("pymobiledevice3"), "install the device transport to test USB discovery")
class UsbReconnectTest(unittest.IsolatedAsyncioTestCase):
    async def test_waits_for_original_usb_phone_and_uses_current_serial(self):
        from pymobiledevice3.usbmux import MuxDevice
        from pymobiledevice3.exceptions import DeviceNotFoundError

        other = MuxDevice(2, "1234", "USB")
        wifi = MuxDevice(3, "abcd", "Network")
        selected = MuxDevice(4, "ab-cd", "USB")
        snapshots = [[other, wifi], [selected], [selected]]
        client = object()
        with patch("pymobiledevice3.usbmux.list_devices", side_effect=snapshots), \
             patch("pymobiledevice3.lockdown.create_using_usbmux", side_effect=[DeviceNotFoundError("ABCD"), client]) as connect, \
             patch("device_worker.asyncio.sleep", new_callable=AsyncMock):
            self.assertIs(await device_worker.connect_lockdown("ABCD"), client)
        self.assertEqual(connect.await_count, 2)
        for call in connect.await_args_list:
            self.assertEqual(call.args, ("ab-cd",))
            self.assertEqual(call.kwargs["connection_type"], "USB")

    async def test_missing_usb_target_stays_missing(self):
        from pymobiledevice3.usbmux import MuxDevice
        from pymobiledevice3.exceptions import DeviceNotFoundError

        with patch("pymobiledevice3.usbmux.list_devices", return_value=[MuxDevice(2, "other", "USB")]), \
             patch("pymobiledevice3.lockdown.create_using_usbmux") as connect, \
             patch("device_worker.asyncio.sleep", new_callable=AsyncMock):
            with self.assertRaises(DeviceNotFoundError) as missing:
                await device_worker.connect_lockdown("target")
        connect.assert_not_awaited()
        self.assertIn("刷新设备", device_worker.explain(missing.exception))

    async def test_disconnected_device_not_offered(self):
        from pymobiledevice3.usbmux import MuxDevice
        from pymobiledevice3.exceptions import DeviceNotFoundError

        with patch("pymobiledevice3.usbmux.list_devices", return_value=[MuxDevice(3, "abcd", "USB")]), \
             patch("pymobiledevice3.lockdown.create_using_usbmux", side_effect=DeviceNotFoundError("abcd")), \
             patch("device_worker.emit") as emit:
            await device_worker.discover()
        emit.assert_called_once_with("devices", devices=[])

    async def test_tunnel_retries_opening_only_and_releases_both_handles(self):
        from pymobiledevice3.exceptions import DeviceNotFoundError

        first, second = AsyncMock(), AsyncMock()
        first.aopen.side_effect = DeviceNotFoundError("abcd")
        with patch("pymobiledevice3.remote.rsd_tunnel.PreferredRsdTunnel", side_effect=[first, second]) as create, \
             patch("device_worker.asyncio.sleep", new_callable=AsyncMock):
            async with AsyncExitStack() as stack:
                self.assertIs(await device_worker.open_device_tunnel("abcd", stack), second.aopen.return_value)
                first.aclose.assert_awaited_once()
                second.aclose.assert_not_awaited()
        self.assertEqual([call.kwargs for call in create.call_args_list], [{"serial": "abcd"}] * 2)
        second.aclose.assert_awaited_once()


class PlatformTest(unittest.TestCase):
    def test_windows_signals_do_not_use_asyncio_signal_handler(self):
        loop, stop = Mock(), Mock()
        with patch.object(sys, 'platform', 'win32'), patch('device_worker.signal.signal') as register:
            device_worker.install_stop_signals(loop, stop)
            register.call_args.args[1](None, None)
        loop.add_signal_handler.assert_not_called()
        loop.call_soon_threadsafe.assert_called_once_with(stop.set)

    def test_macos_retains_asyncio_signal_handler(self):
        loop, stop = Mock(), Mock()
        with patch.object(sys, 'platform', 'darwin'):
            device_worker.install_stop_signals(loop, stop)
        self.assertEqual(loop.add_signal_handler.call_count, 2)

    def test_windows_version_boundaries(self):
        with patch.object(sys, 'platform', 'win32'):
            for version in ('12.5', '17', '17.0', '17.3.1'):
                with self.subTest(version=version), self.assertRaisesRegex(RuntimeError, 'Windows'):
                    device_worker.check_platform_version(version)
            for version in ('13.7', '16.7', '17.4', '18.0', '26.0'):
                self.assertEqual(device_worker.check_platform_version(version), int(version.split('.')[0]))
        with patch.object(sys, 'platform', 'darwin'):
            self.assertEqual(device_worker.check_platform_version('17.0'), 17)

    def test_spawn_windows_process_group(self):
        with patch.object(sys, 'platform', 'win32'), patch.object(subprocess, 'CREATE_NEW_PROCESS_GROUP', 512, create=True), patch('server.subprocess.Popen') as spawn:
            server.worker('list')
        self.assertEqual(spawn.call_args.kwargs['creationflags'], 512)
        self.assertNotIn('start_new_session', spawn.call_args.kwargs)

    def test_events_survive_legacy_console_encoding(self):
        output = io.StringIO()
        with patch.object(sys, 'stdout', output):
            device_worker.emit('error', message='请信任电脑')
        wire = output.getvalue().encode('ascii')
        self.assertEqual(json.loads(wire)['message'], '请信任电脑')

    def test_amap_save_without_unix_permissions(self):
        real_os = os
        class WindowsFileAPI:
            def __getattr__(self, name):
                if name == 'fchmod':
                    raise AttributeError(name)
                return getattr(real_os, name)
        with tempfile.TemporaryDirectory() as directory, patch('amap_config.os', WindowsFileAPI()):
            config = AmapConfig(directory)
            config.save({'key':'test_key_1234567890', 'security_code':'test_secret_1234567890'})
            self.assertEqual(config.read()['key'], 'test_key_1234567890')
            self.assertFalse(config.clear()['configured'])


if __name__ == '__main__':
    unittest.main()
