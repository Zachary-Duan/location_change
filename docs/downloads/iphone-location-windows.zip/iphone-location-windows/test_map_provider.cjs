const test=require('node:test'), assert=require('node:assert/strict'), fs=require('node:fs'), vm=require('node:vm');
class Element {
  constructor(){this.value='';this.textContent='';this.hidden=true;this.listeners={};this.classList={toggle(){}};this.contentWindow={postMessage(){}};}
  addEventListener(t,fn){this.listeners[t]=fn;} setAttribute(){} close(){}
  replaceWith(other){this.replacedBy=other;}
}
async function harness(configured=false){
  const elements=new Map(), window=new Element(),document=new Element();window.location={origin:"http://127.0.0.1:12345"};
  const el=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};
  document.createElement=()=>new Element();
  let conversions=0;
  vm.runInNewContext(fs.readFileSync('dist/amap-controller.js','utf8'),{window,document,$:el,token:'test',online:true,updateCoordinates(){},api:async()=>({configured}),LocationCoordinates:{valid:(lng,lat)=>Number.isFinite(lng)&&Number.isFinite(lat)&&Math.abs(lng)<=180&&Math.abs(lat)<=90,gcjToWgs:(lng,lat)=>{conversions++;return{lng:lng-.005,lat:lat-.005};}}});
  await new Promise(resolve=>setImmediate(resolve));
  const currentFrame=()=>{let f=el('amap-frame');while(f.replacedBy)f=f.replacedBy;return f;};
  const message=async(data,source=currentFrame().contentWindow,origin=configured?'null':window.location.origin)=>window.listeners.message({source,origin,data:{scope:'iphone-location-amap',...data}});
  return{el,currentFrame,message,conversions:()=>conversions,window};
}
test('new visitors automatically load the key-free map and preserve WGS84',async()=>{
  const h=await harness();assert.equal(h.currentFrame().src,'/openmap-picker.html');
  await h.message({type:'pick',lng:116.4,lat:39.9,label:'测试位置',id:1});
  assert.equal(h.el('longitude').value,'116.4000000');assert.equal(h.el('latitude').value,'39.9000000');assert.equal(h.conversions(),0);
});
test('configured AMap still converts its coordinates once',async()=>{
  const h=await harness(true);assert.equal(h.currentFrame().src,'/amap-picker.html');
  await h.message({type:'pick',lng:116.4,lat:39.9,label:'测试位置',id:1});
  assert.equal(h.conversions(),1);assert.equal(h.el('longitude').value,'116.3950000');
});
test('foreign windows and locked maps cannot change the selected location',async()=>{
  const h=await harness();await h.message({type:'pick',lng:1,lat:2,label:'wrong'},{});
  assert.equal(h.el('latitude').value,'');h.window.AmapPanel.setLocked(true);
  await h.message({type:'pick',lng:1,lat:2,label:'locked'});assert.equal(h.el('latitude').value,'');
});
