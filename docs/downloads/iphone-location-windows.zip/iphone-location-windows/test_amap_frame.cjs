"use strict";
// Isolated UI regression tests: no browser, real credentials, network or device.
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const vm = require("node:vm");

const html = fs.readFileSync(path.join(__dirname, "dist/amap-picker.html"), "utf8");
const source = fs.readFileSync(path.join(__dirname, "dist/amap-frame.js"), "utf8");

class Element {
  constructor(tagName, attributes = "") {
    this.tagName = tagName;
    this.type = attributes.match(/\btype="([^"]+)"/)?.[1] || "";
    this.disabled = /\bdisabled\b/.test(attributes);
    this.value = "";
    this.children = [];
    this.listeners = new Map();
  }
  addEventListener(type, listener) {
    const listeners = this.listeners.get(type) || [];
    listeners.push(listener);
    this.listeners.set(type, listeners);
  }
  fire(type, fields = {}) {
    const event = {defaultPrevented: false, preventDefault() {this.defaultPrevented = true;}, ...fields};
    for (const listener of this.listeners.get(type) || []) listener(event);
    return event;
  }
  append(child) { this.children.push(child); }
  replaceChildren(...children) { this.children = children; }
  querySelectorAll(tagName) {
    return this.children.flatMap(child => [
      ...(child.tagName === tagName ? [child] : []), ...child.querySelectorAll(tagName)
    ]);
  }
}

function harness() {
  const elements = new Map();
  for (const [, tagName, attributes, id] of html.matchAll(/<([a-z]+)\b([^>]*\bid="([^"]+)"[^>]*)>/g)) {
    elements.set(id, new Element(tagName, attributes));
  }
  const head = new Element("head"), window = new Element("window");
  const messages = [], searches = [], geocodes = [], observers = [], timers = new Map();
  const origin = "http://127.0.0.1:12345";
  const parent = {postMessage(data, target) {messages.push({data, target});}};
  let map, marker, nextTimer = 0;
  const AMap = {
    Map: class extends Element {
      constructor(id, options) {super("map"); map = this; this.options = options; this.resizeCount = 0;}
      on(type, callback) {this.addEventListener(type, callback);}
      setZoomAndCenter(zoom, center) {this.zoom = zoom; this.center = center;}
      resize() {this.resizeCount++;}
    },
    Marker: class {
      constructor() {marker = this;}
      setPosition(position) {this.position = position;}
      setMap(value) {this.map = value;}
    },
    PlaceSearch: class {
      search(keyword, callback) {searches.push({keyword, callback});}
    },
    Geocoder: class { getAddress(position, callback) {geocodes.push({position, callback});} },
  };
  window.AMap = AMap;
  window.ResizeObserver = class {
    constructor(callback) {this.callback = callback; observers.push(this);}
    observe(element) {this.target = element;}
    disconnect() {this.disconnected = true;}
  };
  vm.runInNewContext(source, {
    window, parent, AMap, URL, location: {href: origin + "/amap-picker.html"},
    document: {head, getElementById: id => elements.get(id), createElement: tag => new Element(tag)},
    setTimeout(callback) {const id = ++nextTimer; timers.set(id, callback); return id;},
    clearTimeout(id) {timers.delete(id);},
  }, {filename: "amap-frame.js"});
  function message(data) {
    window.fire("message", {source: parent, origin, data: {scope: "iphone-location-amap", ...data}});
  }
  message({type: "init", key: "fake-test-key", serviceHost: origin + "/amap-proxy/test/_AMapService", locked: false});
  head.children[0].onload();
  map.fire("complete");
  return {el: id => elements.get(id), searches, geocodes, observers, messages, map, marker, message, window};
}

test("search click works without a native form submission", () => {
  const h = harness();
  assert.equal(h.el("search-form").tagName, "div");
  assert.equal(h.el("search-button").type, "button");
  h.el("search").value = "  杭州西湖  ";
  h.el("search-button").fire("click");
  assert.equal(h.searches.length, 1);
  assert.equal(h.searches[0].keyword, "杭州西湖");
  assert.equal(h.el("search-button").disabled, true);
});

test("Enter searches and prevents native submission", () => {
  const h = harness();
  h.el("search").value = "上海人民广场";
  const event = h.el("search").fire("keydown", {key: "Enter", isComposing: false});
  assert.equal(event.defaultPrevented, true);
  assert.equal(h.searches.length, 1);
  assert.equal(h.searches[0].keyword, "上海人民广场");
});

test("Enter while confirming an IME candidate does not search", () => {
  const h = harness();
  h.el("search").value = "西湖";
  const event = h.el("search").fire("keydown", {key: "Enter", isComposing: true});
  assert.equal(event.defaultPrevented, false);
  assert.equal(h.searches.length, 0);
  assert.equal(h.el("search-button").disabled, false);
});

test("an in-flight search blocks duplicate click and Enter until completion", () => {
  const h = harness();
  h.el("search").value = "北京故宫";
  h.el("search-button").fire("click");
  h.el("search-button").fire("click");
  h.el("search").fire("keydown", {key: "Enter"});
  assert.equal(h.searches.length, 1);
  h.searches[0].callback("no_data", {});
  assert.equal(h.el("search-button").disabled, false);
  h.el("search-button").fire("click");
  assert.equal(h.searches.length, 2);
});

test("result selection reports coordinates; a parent lock blocks selecting and searching", () => {
  const h = harness();
  h.el("search").value = "测试地点";
  h.el("search-button").fire("click");
  h.searches[0].callback("complete", {poiList: {pois: [{
    name: "测试地点", cityname: "测试城市", address: "测试地址",
    location: {getLng: () => 121.5, getLat: () => 31.2}
  }]}});
  const [result] = h.el("search-results").querySelectorAll("button");
  assert.ok(result);
  assert.equal(h.messages.filter(({data}) => data.type === "pick").length, 0);
  h.message({type: "lock", locked: true});
  assert.equal(result.disabled, true);
  result.fire("click");
  h.el("search-button").fire("click");
  assert.equal(h.searches.length, 1);
  assert.equal(h.messages.filter(({data}) => data.type === "pick").length, 0);
  h.message({type: "lock", locked: false});
  result.fire("click");
  const picks = h.messages.filter(({data}) => data.type === "pick");
  assert.equal(picks.length, 1);
  assert.equal(picks[0].data.lng, 121.5);
  assert.equal(picks[0].data.lat, 31.2);
  assert.equal(picks[0].data.label, "测试地点");
  assert.equal(h.el("map-status").textContent, "测试地点");
  assert.equal(h.el("search-results").children.length, 0);
  assert.equal(h.map.zoom, 16);
  assert.equal(h.marker.map, h.map);
});

test("map picking shows a label and resolved address without coordinate numbers", () => {
  const h = harness();
  h.map.fire("click", {lnglat: {getLng: () => 121.5, getLat: () => 31.2}});
  assert.equal(h.el("map-status").textContent, "地图选点");
  assert.equal(h.geocodes.length, 1);
  h.geocodes[0].callback("complete", {regeocode: {formattedAddress: "上海市黄浦区人民广场"}});
  assert.equal(h.el("map-status").textContent, "上海市黄浦区人民广场");
  assert.equal(h.messages.at(-1).data.type, "label");
  assert.equal(h.messages.at(-1).data.label, "上海市黄浦区人民广场");
});

test("container changes resize the map without enabling the SDK iframe sensor", () => {
  const h = harness();
  assert.equal(h.map.options.resizeEnable, false);
  const [observer] = h.observers;
  assert.equal(observer.target, h.el("map"));
  const resize = (width, height) => observer.callback([{contentRect: {width, height}}]);
  resize(800, 600);
  resize(800, 600);
  resize(0, 0);
  assert.equal(h.map.resizeCount, 1);
  resize(390, 300);
  assert.equal(h.map.resizeCount, 2);
  h.window.fire("pagehide");
  assert.equal(observer.disconnected, true);
});
